from setuptools import setup, find_packages

from setuptools import setup, find_packages
import os

# Read long description from README
with open('README.md', 'r', encoding='utf-8') as f:
    long_description = f.read()

# Get dependencies
with open('requirements.txt', 'r') as f:
    requirements = f.read().splitlines()

setup(
    name="ReportSender",
    version="1.0.0",
    author="eliki",
    author_email="elijahkiragum@gmail.com",
    description="Automated student report sender to parents",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(),
    include_package_data=True,
    install_requires=requirements,
    entry_points={
        'gui_scripts': [
            'reportsender=report_sender.main:main',
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
    keywords='education reports email automation',
)
